﻿const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');

const dataRouter = require('./routes/dataRouter');
const authRouter = require('./routes/authRouter'); // ✅ BURASI YENİ

const app = express();
app.use(cors());
app.use(express.json());

mongoose.connect('mongodb://127.0.0.1:27017/mydatabase')
    .then(() => console.log('✅ MongoDB bağlantısı başarılı'))
    .catch(err => console.error('❌ MongoDB bağlantı hatası:', err));

app.use('/api/data', dataRouter);
app.use('/api/auth', authRouter); // ✅ BURASI YENİ

const PORT = 3000;
app.listen(PORT, () => {
    console.log(`🚀 Sunucu çalışıyor: http://localhost:${PORT}`);
});
