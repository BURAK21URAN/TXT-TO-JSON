const mongoose = require('mongoose');

const RecordSchema = new mongoose.Schema({}, { strict: false });
// JSON key'leri dinamik olaca�� i�in strict: false kullan�yoruz

module.exports = mongoose.model('Record', RecordSchema);
