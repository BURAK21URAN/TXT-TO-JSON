const mongoose = require('mongoose');

const DataSchema = new mongoose.Schema({}, { strict: false });

const JsonModel = mongoose.model('Json', DataSchema);

module.exports = JsonModel;
