﻿const express = require('express');
const router = express.Router();
const JsonModel = require('../models/DataModel'); 

router.post('/', async (req, res) => {
    try {
        await JsonModel.insertMany(req.body);
        console.log('✅ Veri MongoDB\'ye kaydedildi');
        res.status(200).send({ message: 'Veri başarıyla kaydedildi' });
    } catch (err) {
        console.error('❌ Hata:', err);
        res.status(500).send({ error: 'Veri kaydedilemedi' });
    }
});

module.exports = router;
